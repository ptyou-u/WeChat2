//
//  VIewModel.m
//  WeChat
//
//  Created by p_tyou on 2021/6/20.
//

#import "VIewModel.h"

@implementation VIewModel

- (instancetype)initWithDict:(NSDictionary *)dict {
    if (self = [super init]){
        [self setValuesForKeysWithDictionary:dict];
    }
    return self;
}

+ (instancetype)MomentsWithDict:(NSDictionary *)dict {
    return [[self alloc]initWithDict:dict];
}

@end
