//
//  MonmentTableViewCell.h
//  WeChat
//
//  Created by p_tyou on 2021/7/6.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@class  MomentsFrame;
@interface MonmentTableViewCell : UITableViewCell
@property (nonatomic, strong) MomentsFrame *moment;
@end

NS_ASSUME_NONNULL_END
