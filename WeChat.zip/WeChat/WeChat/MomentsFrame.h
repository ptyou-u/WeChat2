//
//  MomentsFrame.h
//  WeChat
//
//  Created by p_tyou on 2021/7/9.
//

#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>
#import <UIKit/UIKit.h>

#define nameFont [UIFont systemFontOfSize:12]
#define textFont [UIFont systemFontOfSize:12]

NS_ASSUME_NONNULL_BEGIN
@class VIewModel;
@interface MomentsFrame : NSObject

@property (nonatomic, strong) VIewModel *moment;
@property (nonatomic, assign, readonly) CGRect iconFrame;
@property (nonatomic, assign, readonly) CGRect nameFrame;
@property (nonatomic, assign, readonly) CGRect textFrame;
@property (nonatomic, assign, readonly) CGRect picFrame;
@property (nonatomic, assign, readonly) CGFloat rowHeight;

@end

NS_ASSUME_NONNULL_END
