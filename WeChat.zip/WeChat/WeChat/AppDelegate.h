//
//  AppDelegate.h
//  WeChat
//
//  Created by p_tyou on 2021/6/18.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

