//
//  ViewController.m
//  WeChat
//
//  Created by p_tyou on 2021/6/18.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    UITabBarController *tabBar = [[UITabBarController alloc]init];
    NSMutableArray *array = [[NSMutableArray alloc]init];
    for (int i=0; i<5; i++) {
        UIViewController *con = [[UIViewController alloc]init];
        
    }
    tabBar.tabBar.barTintColor = [UIColor greenColor];
    tabBar.tabBar.backgroundColor = [UIColor whiteColor];
    [self presentViewController:tabBar animated:YES completion:nil];
}
@end
