//
//  MonmentTableViewCell.m
//  WeChat
//
//  Created by p_tyou on 2021/7/6.
//

#import "MonmentTableViewCell.h"
#import "VIewModel.h"
#import "MomentsFrame.h"

#define nameFont [UIFont systemFontOfSize:12]
#define textFont [UIFont systemFontOfSize:12]

@interface MonmentTableViewCell ()

@property (nonatomic, weak) UIImageView *imgViewIcon;
@property (nonatomic, weak) UILabel *lblNicName;
@property (nonatomic, weak) UILabel *lblText;
@property (nonatomic, weak) UIImageView *imgViewPicture;

@end

@implementation MonmentTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]){
        
        UIImageView *imgViewIcon = [[UIImageView alloc]init];
        [self.contentView addSubview:imgViewIcon];
        self.imgViewIcon = imgViewIcon;
        
        UILabel *lblNicName = [[UILabel alloc]init];
        [self.contentView addSubview:lblNicName];
        self.lblNicName = lblNicName;
        lblNicName.font = nameFont;
        
        UILabel *lblText = [[UILabel alloc]init];
        [self.contentView addSubview:lblText];
        self.lblText = lblText;
        
        UIImageView *imgViewPicture = [[UIImageView alloc]init];
        [self.contentView addSubview:imgViewPicture];
        self.imgViewPicture = imgViewPicture;
        
    }
    return  self;
}

- (void)setMoment:(MomentsFrame *)moment {
    _moment = moment;
    
    [self settingData];
    
    [self settingFrame];
}



- (void)settingData {
    VIewModel *model = self.moment.moment;
    
    self.imgViewIcon.image = [UIImage imageNamed:model.icon];
    
    self.lblNicName.text = model.name;
    
    self.lblText.text = model.text;
    if (model.picture) {
        self.imgViewPicture.image = [UIImage imageNamed:model.picture];
        self.imgViewPicture.hidden = NO;
    }
    else{
        self.imgViewPicture.hidden = YES;
    }
}

- (void)settingFrame {
    

    self.imgViewIcon.frame = self.moment.iconFrame;
    

    
    self.lblNicName.frame = self.moment.nameFrame;
    
    self.lblText.frame = self.moment.textFrame;
    
    self.imgViewPicture.frame = self.moment.picFrame;
    
    
}

- (CGSize)sizeWithText:(NSString *)text andMaxSize:(CGSize)maxSize andFont:(UIFont *)font{
    NSDictionary *attr = @{NSFontAttributeName : font};
    return [text boundingRectWithSize:maxSize options:NSStringDrawingUsesLineFragmentOrigin attributes:attr context:nil].size;
}
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
