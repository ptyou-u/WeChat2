//
//  DiscoverViewController.h
//  WeChat
//
//  Created by p_tyou on 2021/7/5.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DiscoverViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
