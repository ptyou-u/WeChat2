//
//  MomentsFrame.m
//  WeChat
//
//  Created by p_tyou on 2021/7/9.
//

#import "MomentsFrame.h"
#import "VIewModel.h"


@implementation MomentsFrame

- (void)setMoment:(VIewModel *)moment {
    
    _moment = moment;
    
    CGFloat margin = 10;
    
    CGFloat iconW = 35;
    CGFloat iconH = 35;
    CGFloat iconX = margin;
    CGFloat iconY = margin;
    _iconFrame = CGRectMake(iconX, iconY, iconW, iconH);
    
    NSString *nickName = moment.name;
    CGFloat nameX = CGRectGetMaxX(_iconFrame) + margin;
    
    CGSize nameSize = [self sizeWithText:nickName andMaxSize:CGSizeMake(300, MAXFLOAT) andFont:nameFont];
    
    CGFloat nameW = nameSize.width;
    CGFloat nameH = nameSize.height;
    CGFloat nameY = iconY + (iconH - nameH) / 2;
    
    _nameFrame = CGRectMake(nameX, nameY, nameW, nameH);
    
    
    CGFloat textX = iconX;
    CGFloat textY = CGRectGetMaxY(_iconFrame) + margin;
    CGSize textSize = [self sizeWithText:moment.text andMaxSize:CGSizeMake(CGFLOAT_MAX, MAXFLOAT) andFont:textFont];
    CGFloat textW = textSize.width;
    CGFloat textH = textSize.height;
    _textFrame = CGRectMake(textX, textY, textW, textH);
    
    CGFloat picW = 100;
    CGFloat picH = 100;
    CGFloat picX = iconX;
    CGFloat picY = CGRectGetMaxY(_textFrame) + margin;
    _picFrame = CGRectMake(picX, picY, picW, picH);
    
    CGFloat rowHeight = 0;
    if (self.moment.picture) {
        rowHeight = CGRectGetMaxY(_picFrame) + margin;
        
    }
    else{
        rowHeight = CGRectGetMaxY(_textFrame) + margin;
    }
    
    _rowHeight = rowHeight;
}

- (CGSize)sizeWithText:(NSString *)text andMaxSize:(CGSize)maxSize andFont:(UIFont *)font{
    NSDictionary *attr = @{NSFontAttributeName : font};
    return [text boundingRectWithSize:maxSize options:NSStringDrawingUsesLineFragmentOrigin attributes:attr context:nil].size;
}

@end
