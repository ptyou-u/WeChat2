//
//  VIewModel.h
//  WeChat
//
//  Created by p_tyou on 2021/6/20.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface VIewModel : NSObject
///帖子唯一id
@property (nonatomic, copy) NSString *post_id;

///头像
@property (nonatomic, copy) NSString *icon;

///昵称
@property (nonatomic, copy) NSString *name;

///时间戳
@property (nonatomic, strong) NSNumber *publish_time;

///帖子内容
@property (nonatomic, copy) NSString *text;

///图片数组
@property (nonatomic, copy) NSArray *pics;
@property (nonatomic, copy) NSString *picture;



///用户举报（用于举报，屏蔽此人的请求）
@property (nonatomic, copy) NSString *uid;

///是否是自己的帖子（用于删除和举报帖子）
@property (nonatomic, strong) NSNumber *is_self;

///帖子点赞数
@property (nonatomic, strong) NSNumber *praise_count;

///帖子评论数
@property (nonatomic, strong) NSNumber *comment_count;

///是否关注圈子
@property (nonatomic, strong) NSNumber *is_follow_topic;

///是否点赞帖子
@property (nonatomic, strong) NSNumber *is_praised;

//@property (nonatomic, assign) CGFloat cellHeight;

- (instancetype)initWithDict:(NSDictionary *)dict;
+ (instancetype)MomentsWithDict:(NSDictionary *)dict;

@end

NS_ASSUME_NONNULL_END
