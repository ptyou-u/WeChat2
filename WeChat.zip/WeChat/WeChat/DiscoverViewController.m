//
//  DiscoverViewController.m
//  WeChat
//
//  Created by p_tyou on 2021/7/5.
//

#import "DiscoverViewController.h"
#import "VIewModel.h"
#import "MonmentTableViewCell.h"

@interface DiscoverViewController ()

@property (nonatomic, strong) NSArray *Moments;

@end

@implementation DiscoverViewController

- (NSArray *)Moments{
    if (_Moments == nil) {
        NSString *path = [[NSBundle mainBundle] pathForResource:@"Moments.plist" ofType:nil];
        NSArray *arrayDict = [NSArray arrayWithContentsOfFile:path];
        NSMutableArray *arrayModels = [NSMutableArray array];
        for (NSDictionary *dict in arrayDict) {
            VIewModel *model = [VIewModel MomentsWithDict:dict];
            [arrayModels addObject:model];
        }
        _Moments = arrayModels;
    }
    
    return _Moments;
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    UIView *headerView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 414, 100)];
    headerView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:headerView];
//    self.view.backgroundColor = [UIColor whiteColor];
    UITableView *tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 100, 414, 800) style:UITableViewStyleGrouped];
    [self.view addSubview:tableView];
    
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
