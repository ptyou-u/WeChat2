//
//  SceneDelegate.h
//  WeChat
//
//  Created by p_tyou on 2021/6/18.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

