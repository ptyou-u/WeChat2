//
//  tabBarViewController.m
//  WeChat
//
//  Created by p_tyou on 2021/6/18.
//

#import "tabBarViewController.h"
#import "ChatsTableViewController.h"
#import "ContactsTableViewController.h"
#import "MeTableViewController.h"
#import "DiscoverViewController.h"
#import "DiscoverTableViewController.h"

@interface tabBarViewController ()

@end

@implementation tabBarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self loadViewController];
}

- (void)loadViewController{
    //创建Controller
    ChatsTableViewController *ChatsVC = [[ChatsTableViewController alloc]init];
    ContactsTableViewController *ContactsVC = [[ContactsTableViewController alloc]init];
    DiscoverTableViewController *DiscoverVC = [[DiscoverTableViewController alloc]init];
    MeTableViewController *MeVC = [[MeTableViewController alloc]init];
    //添加控制器
    self.viewControllers = @[ChatsVC, ContactsVC, DiscoverVC, MeVC];
    //设置tabBarButton
    [[UIImage imageNamed:@"icon1"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    ChatsVC.tabBarItem = [[UITabBarItem alloc]initWithTitle:@"首页" image:[UIImage imageNamed:@""] selectedImage:[UIImage imageNamed:@""] ];
    ContactsVC.tabBarItem = [[UITabBarItem alloc]initWithTitle:@"通讯录" image:[UIImage imageNamed:@""] selectedImage:[UIImage imageNamed:@""]];
    DiscoverVC.tabBarItem = [[UITabBarItem alloc]initWithTitle:@"发现" image:[UIImage imageNamed:@""] selectedImage:[UIImage imageNamed:@""]];
    MeVC.tabBarItem = [[UITabBarItem alloc]initWithTitle:@"我的" image:[UIImage imageNamed:@""] selectedImage:[UIImage imageNamed:@""]];
    self.tabBar.backgroundColor = [UIColor whiteColor];
    self.tabBar.tintColor = [UIColor greenColor];
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
